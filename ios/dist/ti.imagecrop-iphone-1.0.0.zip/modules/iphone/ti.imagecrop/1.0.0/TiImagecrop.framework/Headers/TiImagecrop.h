//
//  TiImagecrop.h
//  titanium-image-crop
//
//  Created by Your Name
//  Copyright (c) 2019 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiImagecrop.
FOUNDATION_EXPORT double TiImagecropVersionNumber;

//! Project version string for TiImagecrop.
FOUNDATION_EXPORT const unsigned char TiImagecropVersionString[];

#import "TiImagecropModuleAssets.h"
